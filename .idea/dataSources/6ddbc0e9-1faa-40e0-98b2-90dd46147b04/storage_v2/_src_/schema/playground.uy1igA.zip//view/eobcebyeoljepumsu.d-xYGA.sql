create definer = playground@`%` view 업체별제품수 as
select `playground`.`sales_products`.`prdmaker`      AS `prdmaker`,
       count(`playground`.`sales_products`.`prodno`) AS `제품수`
from `playground`.`sales_products`
group by `playground`.`sales_products`.`prdmaker`;

