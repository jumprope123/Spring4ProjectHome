create definer = playground@`%` view 제품2 as
select `playground`.`sales_product2`.`prodno`   AS `prodno`,
       `playground`.`sales_product2`.`prdname`  AS `prdname`,
       `playground`.`sales_product2`.`stoke`    AS `stoke`,
       `playground`.`sales_product2`.`price`    AS `price`,
       `playground`.`sales_product2`.`prdmaker` AS `prdmaker`
from `playground`.`sales_product2`;

