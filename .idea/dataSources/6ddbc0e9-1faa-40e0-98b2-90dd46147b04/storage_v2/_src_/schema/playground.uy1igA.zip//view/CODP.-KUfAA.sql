create definer = playground@`%` view CODP as
select `ol`.`제품번호` AS `제품번호`,
       `o`.`주문번호`  AS `주문번호`,
       `c`.`고객번호`  AS `고객번호`,
       `c`.`고객이름`  AS `고객이름`,
       `c`.`주소`    AS `주소`,
       `c`.`시도`    AS `시도`,
       `c`.`우편번호`  AS `우편번호`,
       `c`.`전화번호`  AS `전화번호`,
       `o`.`주문일`   AS `주문일`,
       `o`.`납기일`   AS `납기일`,
       `o`.`인사번호`  AS `인사번호`,
       `ol`.`수량`   AS `수량`,
       `p`.`제품이름`  AS `제품이름`,
       `p`.`제품분류`  AS `제품분류`,
       `p`.`단가`    AS `단가`,
       `p`.`재고량`   AS `재고량`
from (((`playground`.`고객` `c` join `playground`.`주문` `o` on (`c`.`고객번호` = `o`.`고객번호`)) join `playground`.`주문항목` `ol` on (`o`.`주문번호` = `ol`.`주문번호`))
         join `playground`.`제품` `p` on (`ol`.`제품번호` = `p`.`제품번호`));

